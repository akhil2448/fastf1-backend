import fastf1

session_cache = {}


def get_loaded_session(year: int, round_number: int):
    """
    Returns cached loaded FastF1 race session.
    """

    cache_key = (year, round_number)

    if cache_key in session_cache:
        return session_cache[cache_key]

    session = fastf1.get_session(
        year,
        round_number,
        "R"
    )

    session.load(
        laps=True,
        telemetry=True,
        weather=True
    )

    session_cache[cache_key] = session

    return session